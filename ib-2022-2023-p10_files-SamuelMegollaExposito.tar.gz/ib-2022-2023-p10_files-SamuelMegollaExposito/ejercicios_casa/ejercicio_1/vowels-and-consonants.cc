#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string>

using namespace std;
void Usage(int argc, char *argv[]);
void Usage(int argc, char *argv[]){
    /*Muestra el modo de uso*/
    if(argc != 2) {
        cout <<argv[0] <<": Falta el nombre del fichero" <<endl;
        cout <<"Pruebe" << argv[0] <<": --help para mas informacion" <<endl;
        exit(EXIT_SUCCESS);
    }
    string parameter{argv[1]};
    if(parameter == "--help"){
        const string kHelperText = "Este programa averigua la palabra mas larga con vocales y otra con consonantes";
    cout << kHelperText << endl;
    exit(EXIT_SUCCESS);
    }
}
void Lectura();
//funcion main.
int main(int argc, char *argv[]){
    Usage(argc,argv);
    Lectura();
    


    return 0;
}
//lectura del archivo
void Lectura(){
    string kVowel, kConsonat;
    int aux1{0}, aux2{0};
    string texto;
    ifstream archivo;
    archivo.open("prueba.txt",ios::in); //modo lectura;

    if(archivo.fail()){
        cout<<"No se pudo abrir el archivo."<<endl;
        exit(1);
    }
    while(!archivo.eof()){ //mientras que no seal el final del archivo.
        getline(archivo,texto);
        //lectura de consonantes y vocales
         int vowels{0}, consonant{0}, i;
        for (i = 0; i < texto.length(); i++) {
            texto[i] = tolower(texto[i]);
            if (!isalpha(texto[i])) {
                vowels = 0;
                consonant = 0;
            } else if (texto[i] == 'a' || texto[i] == 'e' || texto[i] == 'i' || texto[i] == 'o' || texto[i] == 'u') {
                vowels++;
                if (aux1 < vowels) {
                    aux1 = vowels;
                    kVowel = texto;
                }
            } else {
                consonant++;
                if (aux2 < consonant) {
                    aux2 = consonant;
                    kConsonat = texto;
                }
            }
        }
    }
    cout << kVowel << " " << kConsonat << endl;
    archivo.close(); //cerrar el archivo.
}