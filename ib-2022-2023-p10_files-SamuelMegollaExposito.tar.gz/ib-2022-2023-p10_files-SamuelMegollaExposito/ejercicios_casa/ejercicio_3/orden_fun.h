#include<iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

void Usage(int argc, char *argv[]);
void FicheroPalabrasOrdenadas(const string& texto);